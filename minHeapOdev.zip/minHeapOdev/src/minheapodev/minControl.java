package minheapodev;
//HALİL YUŞA AĞCA-02210201061
public class minControl {
    public static boolean minKontrol(int[] array) {
    for (int i=0;i<array.length*2/3;i++) {
        int right =3*i+1;
        int mid=3*i+2;
        int r=3*i+3;
        if (right<array.length&&array[i]>array[right]) {
            return false;
        }
        if (mid<array.length&&array[i]>array[mid]) {
            return false;
        }
        if (r<array.length&&array[i]>array[r]) {
            return false;
        }
    }
    return true;
}
    
    
    public static void donustur(int[] array) {
    for (int i=array.length*2/3-1;i>=0;i--) {
        int c=i;
        int right=3*i+1;
        if (right<array.length && array[c]>array[right]) {
            int temp=array[c];
            array[c]=array[right];
            array[right]=temp;
            c=right;
        }
        int mid=3*i+2;
        if (mid<array.length&&array[c]>array[mid]) {
            int temp=array[c];
            array[c]=array[mid];
            array[mid]=temp;
            c=mid;
        }
        int r=3*i+3;
        if (r<array.length&&array[c]>array[r]) {
            int temp=array[c];
            array[c]=array[r];
            array[r]=temp;
        }
    }
}
}
