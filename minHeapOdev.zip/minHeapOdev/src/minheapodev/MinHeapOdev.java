package minheapodev;
import java.util.Scanner;
import java.util.Arrays;
//HALİL YUŞA AĞCA-02210201061
public class MinHeapOdev {

    
    public static void main(String[] args) {
         minControl heapKontrol = new minControl();
        minControl heapYapar = new minControl();
        
        
        Scanner scan = new Scanner(System.in);
        System.out.print("String giriniz:");
        String yazi = scan.nextLine();
        String[] bolunmus = yazi.split(",");
        int d[] = new int[bolunmus.length];
        int sayac=0;
        for (String bol : bolunmus) {
            int yeni1 = Integer.parseInt(bol);
            d[sayac]=yeni1;
            sayac++;
        }

        if (heapKontrol.minKontrol(d)) {
            System.out.println("Minheap'tir!");
            System.out.println(Arrays.toString(d));
        }
        else {
            System.out.println("Minheap Değildir!");
            System.out.println(Arrays.toString(d));
            heapYapar.donustur(d);
            System.out.println(Arrays.toString(d));
              
        } 
        
    }
}
    
    

